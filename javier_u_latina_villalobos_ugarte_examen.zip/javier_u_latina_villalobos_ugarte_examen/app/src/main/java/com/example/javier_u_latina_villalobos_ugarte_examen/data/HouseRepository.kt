package com.example.javier_u_latina_villalobos_ugarte_examen.data

import androidx.lifecycle.LiveData
import com.example.javier_u_latina_villalobos_ugarte_examen.data.database.interfaces.HouseDao
import com.example.javier_u_latina_villalobos_ugarte_examen.model.houseJavier
import javax.inject.Inject

class HouseRepository @Inject constructor(private val houseDao: HouseDao)
{
    fun getAllHouses(): LiveData<List<houseJavier>> {
        return houseDao.getAllHouses()
    }

    suspend fun insert(houseJavier: houseJavier) {
        houseDao.insert(houseJavier)
    }

    suspend fun update(houseJavier: houseJavier) {
        houseDao.update(houseJavier)
    }

    suspend fun deleteAllHouses() {
        houseDao.deleteAllHouses()
    }
    suspend fun delete(houseJavier: houseJavier) {
        houseDao.delete(houseJavier)
    }

}