package com.example.javier_u_latina_villalobos_ugarte_examen.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.javier_u_latina_villalobos_ugarte_examen.data.HouseRepository
import com.example.javier_u_latina_villalobos_ugarte_examen.model.houseJavier
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HouseViewModel @Inject constructor(
    private val repository: HouseRepository
) : ViewModel() {

    val allHouses: LiveData<List<houseJavier>> get() = repository.getAllHouses()


    fun insert(houseJavier: houseJavier) = viewModelScope.launch {
        repository.insert(houseJavier)
    }

    fun update(houseJavier: houseJavier) = viewModelScope.launch {
        repository.update(houseJavier)
    }

    fun deleteItem(houseJavier: houseJavier) {
        viewModelScope.launch {
            repository.delete(houseJavier)
        }
    }

    fun deleteAllItems() = viewModelScope.launch {
        repository.deleteAllHouses()
    }
}
