package com.example.javier_u_latina_villalobos_ugarte_examen.di

import android.content.Context
import com.example.javier_u_latina_villalobos_ugarte_examen.data.HouseRepository
import com.example.javier_u_latina_villalobos_ugarte_examen.data.database.AppDatabase
import com.example.javier_u_latina_villalobos_ugarte_examen.data.database.interfaces.HouseDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule
{
    @Provides
    @Singleton
    fun provideAppDatabase(@ApplicationContext context: Context): AppDatabase {
        return AppDatabase.getDatabase(context)
    }

    @Provides
    @Singleton
    fun provideHouseDao(appDatabase: AppDatabase): HouseDao {
        return appDatabase.houseDao()
    }

    @Provides
    @Singleton
    fun provideHouseRepository(houseDao:HouseDao): HouseRepository {
        return HouseRepository(houseDao)
    }

}