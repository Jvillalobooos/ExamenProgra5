package com.example.javier_u_latina_villalobos_ugarte_examen.userinterfaz

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.javier_u_latina_villalobos_ugarte_examen.model.houseJavier
import com.example.javier_u_latina_villalobos_ugarte_examen.viewmodel.HouseViewModel

@Composable
fun AddhouseScreen(
    navController: NavController,
    viewModel: HouseViewModel = hiltViewModel()
) {
    var houseName by remember { mutableStateOf("") } // Estado para el nombre
    var houseDesc by remember { mutableStateOf("") } // Estado para el nombre
    var houseMeters by remember { mutableStateOf("0.0") } //Estado para los metros

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        OutlinedTextField(
            value = houseName,
            onValueChange = { houseName = it },
            label = { Text("Nombre de la casa") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = houseDesc,
            onValueChange = { houseDesc = it },
            label = { Text("Descripcion de la casa") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = houseMeters,
            onValueChange = { newValue ->
                if (newValue.toDoubleOrNull() != null) { //Evita que el usuario ingrese texto inválido
                    houseMeters = newValue
                }
            },
            label = { Text("Metros cuadrados de la casa") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                if (houseName.isNotBlank() && houseMeters.toDoubleOrNull() != null) {
                    val newHouse = houseJavier(
                        name = houseName,
                        square_meters = houseMeters.toDouble()
                    )
                    viewModel.insert(newHouse) // Se agrega a la base de datos
                    navController.popBackStack() // Regresar a la pantalla anterior
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Agregar casa")
        }
    }
}