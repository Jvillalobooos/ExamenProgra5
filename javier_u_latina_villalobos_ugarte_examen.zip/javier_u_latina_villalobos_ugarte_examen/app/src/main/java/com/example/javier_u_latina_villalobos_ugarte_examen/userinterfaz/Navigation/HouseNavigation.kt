package com.example.javier_u_latina_villalobos_ugarte_examen.userinterfaz.Navigation

import androidx.compose.runtime.Composable
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.javier_u_latina_villalobos_ugarte_examen.model.houseJavier
import com.example.javier_u_latina_villalobos_ugarte_examen.userinterfaz.AddhouseScreen
import com.example.javier_u_latina_villalobos_ugarte_examen.userinterfaz.EdithouseScreen
import com.example.javier_u_latina_villalobos_ugarte_examen.userinterfaz.houseListScreen
import com.example.javier_u_latina_villalobos_ugarte_examen.viewmodel.HouseViewModel
import com.google.gson.Gson

@Composable
fun Navigation(viewModelStoreOwner: ViewModelStoreOwner = LocalViewModelStoreOwner.current!!) {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = "houseList"
    ) {
        // Pantalla principal - Lista de casas
        composable("houseList") {
            val viewModel: HouseViewModel = hiltViewModel(viewModelStoreOwner)
            houseListScreen(navController = navController, viewModel = viewModel)
        }

        // Pantalla para agregar una casa
        composable("addHouse") {
            val viewModel: HouseViewModel = hiltViewModel(viewModelStoreOwner)
            AddhouseScreen(navController = navController, viewModel = viewModel)
        }

        // Pantalla para editar una casa
        composable(
            route = "editHouse/{itemJson}",
            arguments = listOf(
                navArgument("itemJson") {
                    type = NavType.StringType
                }
            )
        ) { backStackEntry ->
            // Recuperamos el JSON de la casa desde los argumentos
            val json = backStackEntry.arguments?.getString("itemJson")
            val house = json?.let { Gson().fromJson(it, houseJavier::class.java) }

            val viewModel: HouseViewModel = hiltViewModel(viewModelStoreOwner)

            if (house != null) {
                EdithouseScreen(
                    houseJavier = house,
                    viewModel = viewModel,
                    navController = navController
                )
            } else {
                // Manejar error si `house` es `null`
                navController.popBackStack() // Regresa a la lista si la casa no es válida
            }
        }
    }
}
