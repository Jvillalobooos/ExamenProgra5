package com.example.javier_u_latina_villalobos_ugarte_examen.data.database.interfaces

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.javier_u_latina_villalobos_ugarte_examen.model.houseJavier

@Dao
interface HouseDao
{
    @Insert
    suspend fun insert(houseJavier: houseJavier)

    @Update
    suspend fun update(houseJavier: houseJavier)

    @Query("SELECT * FROM houses")
    fun getAllHouses(): LiveData<List<houseJavier>>

    @Query("DELETE FROM houses")
    suspend fun deleteAllHouses()

    @Delete
    suspend fun delete(houseJavier: houseJavier)
}