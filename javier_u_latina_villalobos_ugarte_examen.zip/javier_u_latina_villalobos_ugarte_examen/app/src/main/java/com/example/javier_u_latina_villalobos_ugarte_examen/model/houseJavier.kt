package com.example.javier_u_latina_villalobos_ugarte_examen.model
import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "houses")
data class houseJavier(

    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String = "",
    val descripccion: String ="",
    val square_meters: Double=0.0,
    val apellido2 : String = "Ugarte",
    val isSelected: Boolean = false
) : Serializable