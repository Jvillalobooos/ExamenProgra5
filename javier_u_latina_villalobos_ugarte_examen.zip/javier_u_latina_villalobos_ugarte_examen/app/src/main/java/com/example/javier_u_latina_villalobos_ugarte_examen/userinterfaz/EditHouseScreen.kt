package com.example.javier_u_latina_villalobos_ugarte_examen.userinterfaz

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.javier_u_latina_villalobos_ugarte_examen.model.houseJavier
import com.example.javier_u_latina_villalobos_ugarte_examen.viewmodel.HouseViewModel

@Composable
fun EdithouseScreen(
    houseJavier: houseJavier,
    viewModel: HouseViewModel = hiltViewModel(),
    navController: NavController
) {
    var houseName by remember { mutableStateOf(houseJavier.name) }
    var houseMeters by remember { mutableStateOf(houseJavier.square_meters.toString()) } // Estado para los metros cuadrados
    var houseDesc by remember { mutableStateOf(houseJavier.name) } // Estado para la descripción

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        TextField(
            value = houseName,
            onValueChange = { houseName = it },
            label = { Text("Nuevo nombre de la casa") },
            modifier = Modifier.fillMaxWidth()
        )

        TextField(
            value = houseDesc,
            onValueChange = { houseDesc = it },
            label = { Text("Nueva descripción de la casa") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = houseMeters,
            onValueChange = { newValue ->
                if (newValue.matches(Regex("^\\d*\\.?\\d*\$"))) { // 🔥 Solo permite números y decimales
                    houseMeters = newValue
                }
            },
            label = { Text("Nuevos metros cuadrados de la casa") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                val updatedMeters = houseMeters.toDoubleOrNull() ?: houseJavier.square_meters
                if (houseName.isNotBlank() && updatedMeters > 0.0) {
                    val updatedHouse = houseJavier.copy(
                        name = houseName,
                        square_meters = updatedMeters // ✅ Ahora también se actualizan los metros cuadrados
                    )
                    viewModel.update(updatedHouse) // 🔥 Se actualiza en la base de datos
                    navController.popBackStack() // Regresa a la pantalla anterior
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Guardar cambios")
        }
    }
}
