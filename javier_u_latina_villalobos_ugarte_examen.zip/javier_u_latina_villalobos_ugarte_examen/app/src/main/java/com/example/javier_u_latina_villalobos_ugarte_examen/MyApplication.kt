package com.example.javier_u_latina_villalobos_ugarte_examen

import android.app.Application
import dagger.hilt.android.HiltAndroidApp


@HiltAndroidApp
class MyApplication: Application()
